import argparse

parser = argparse.ArgumentParser()
parser.add_argument("input_filename", help="the name of the input file to process")
parser.add_argument("output_filename", help="the name of the output file to generate")
args = parser.parse_args()

input_filename = args.input_filename
output_filename = args.output_filename

max_el = 0
try:
	with open(input_filename, 'r') as input_file:
		for line in input_file:
			el = int(line)
			if (el > max_el):
				max_el = el
except IOError:
	print("Could not read file:", input_filename)

with open(output_filename, 'w') as output_file:
	output_file.write(str(max_el)+"\n")

	
