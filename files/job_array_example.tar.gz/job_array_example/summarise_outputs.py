num_jobs = 4

summary_filename = "summary_file.csv"

with open(summary_filename, 'w') as summary_file:
		summary_file.write("job, max\n")

		for job in range(1,num_jobs+1):
			try:
				output_filename = "output_" + str(job) + ".txt"
				with open(output_filename, 'r') as output_file:
					file_max = output_file.readline()
					summary_file.write(str(job) + "," + str(file_max))
			except IOError:
				print("Could not read file:", output_filename)


			






